package org.opencv.samples.colorblobdetect;

public class Drive implements Runnable {

	@Override
	public void run() {
//		try{
//		while (!(ColorBlobDetectionActivity.x_now == 200 && ColorBlobDetectionActivity.y_now == 0 && ColorBlobDetectionActivity.theta_now == 0)) {
//			if (!ColorBlobDetectionActivity.isStopped()) {
//				ColorBlobDetectionActivity.driveFromTo(ColorBlobDetectionActivity.x_now,
//				ColorBlobDetectionActivity.y_now, ColorBlobDetectionActivity.theta_now, 200, 0, 0);
//				//ColorBlobDetectionActivity.drive(200);
//			} else {
//				do {
//					ColorBlobDetectionActivity.turn(90);
//					Thread.sleep(2000);
//					
//					ColorBlobDetectionActivity.drive(20, true);
//					Thread.sleep(2000);
//					ColorBlobDetectionActivity.turn(-90);
//					Thread.sleep(2000);
//				} while (ColorBlobDetectionActivity.ReadSensorsMain());
//				ColorBlobDetectionActivity.setStop(false);
//			}
//		}
//		System.out.println(ColorBlobDetectionActivity.x_now + " " + 
//				ColorBlobDetectionActivity.y_now + " " + ColorBlobDetectionActivity.theta_now);
//	
//	}catch(InterruptedException e){}
	}
}
